const { PermissionsBitField } = require('discord.js')

module.exports = {
    name: 'poço',
    aliases: ['poço'],
    description: 'Ative ou desative o poço dos Quartzos',
    usage: 'ativar | desativar',
    cooldown: 1200,
    /** 
     * @param {import('../../Base/client')} client
     * @param {import('discord.js').Message} message
     * @param {string[]} args
    */
    run: async (client, message, args) => {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) return client.sendReply(message, {
            content: `${client.config.emojis.error} ${message.author}, você precisa da permissão \`Gerenciar Servidor\` para ativar ou desativar o poço dos Quartzos no servidor!`
        });
        const poçoData = await client.mysql.getDesejosData();

        // Se for ativar
        if (['ativar'].includes(args[0])) {    
            // Atualizando canais        
            const { channels } = poçoData;
            
            if (!channels.includes(message.channel.id)) channels.push(message.channel.id);
            else return client.sendReply(message, {
                content: `${client.config.emojis.error} ${message.author}, este canal já recebe os novos **Poços de Quartzos**. Espere pelo próximo!`,
            })

            client.mysql.updateDesejosData({ channels });

            // Respondendo
            client.sendReply(message, {
                content: `${client.config.emojis.success} ${message.author}, prontinho! Quando um novo **Poço de Quartzos** for encontrado, enviarei aqui (ele aparece a cada 30 minutos).`,
            })
        }

        // Se for desativar
        if (['desativar'].includes(args[0])) {    
            // Atualizando canais        
            let { channels } = poçoData;
            
            if (channels.includes(message.channel.id)) channels = channels.filter(f => f !== message.channel.id);
            else return client.sendReply(message, {
                content: `${client.config.emojis.error} ${message.author}, este canal ainda não recebe os novos **Poços de Quartzos**`,
            })

            client.mysql.updateDesejosData({ channels });

            // Respondendo
            client.sendReply(message, {
                content: `${client.config.emojis.success} ${message.author}, canal removido! Quando um novo **Poço de Quartzos** for encontrado, não aparecerá mais nesse canal.`,
            })
        }
    }
}