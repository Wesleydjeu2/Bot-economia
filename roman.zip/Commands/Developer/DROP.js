const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, InteractionCollector } = require('discord.js');
const { unabbreviate } = require('util-stunks');
const ms = require('ms');

module.exports = {
    name: 'drop',
    aliases: ['sorteio', 'giveaway'],
    description: 'Comando não disponível.',
    cooldown: 0,
    usage: '<quantidade> <tempo> [ganhadores]',
    run: async (client, message, args) => {
        if (!Object.values(client.config.permissions.moderator).includes(message.author.id)) return;

        const Value = Math.floor(unabbreviate(args[0]));
        const Time = ms(args[1] || '2m');
        let Winners = parseInt(args[2]), Users = [];

        if (!Winners || isNaN(Winners) || Winners > 1000 || Winners < 2) Winners = 1;

        if (isNaN(Value) || Value < 1 || Value > 100_000_000_000_000_000.0) return client.sendReply(message, {
            content: `${client.config.emojis.error} ${message.author}, você precisa fazer um sorteio maior que **1 relâmpago** afinal eu não sou tão pobre assim!.`
        });

        if (isNaN(Time)) return client.sendReply(message, {
            content: `${client.config.emojis.error} ${message.author}, eii! esse tempo não existe!.`
        });
        
        // Calcula a data e hora de término do sorteio
        const endTime = new Date(Date.now() + Time);
        const formattedEndTime = endTime.toLocaleString('pt-BR', {
            timeZone: 'America/Sao_Paulo',
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });

        // CANAL FIXO
        const channel = client.channels.cache.get('1269781645142130738') || client.channels.cache.get('1269781645142130738');
        channel?.send(`${message.author.tag} \`(${message.author.id})\` fez um drop valendo ${client.config.emojis.money} **${Value.toLocaleString()} Relâmpagos** com \`${ms(Time)}\` de duração e ${Winners} ganhadores`).catch(() => null);

        const Embed = new EmbedBuilder()
            .setColor(client.config.colors.default)
            .setFooter({
                text: `Acabará ${formattedEndTime}`,
                iconURL: message.author.displayAvatarURL()
            })
            .setTitle(`**🎁  Drop ${Value.toLocaleString('pt')} Libras** `) // Ajuste de espaços para centralizar
            .setDescription(`${client.config.emojis.money} Clique em 🎉 para participar!`);

        const Button = new ActionRowBuilder().setComponents(
            new ButtonBuilder()
                .setLabel('Participar (0)')
                .setEmoji('🎉')
                .setCustomId('g-join')
                .setStyle(ButtonStyle.Primary)
        );

        const Message = await message.channel.send({
            embeds: [Embed],
            components: [Button]
        });

        const filter = f => f.customId === 'g-join';
        const Collector = new InteractionCollector(client, { filter, time: Time, message: Message });

        Collector.on('collect', async (button) => {
            if (Users.includes(button.user.id)) return button.reply({
                content: `${client.config.emojis.error} ${button.user}, você já está participando do sorteio, quer participar de novo é?!`,
                ephemeral: true,
                allowedMentions: { parse: [] }
            });
            
            const Cooldowns = await client.mysql.getCooldowns(button.user.id, true);
            if (Cooldowns.daily < Date.now()) return button.reply({
                content: `${client.config.emojis.money} ${button.user}, você não pode participar, você ainda não coletou sua recompensa diária, use o comando \`Adaily\` para coletar e poder participar!.`,
                ephemeral: true,
                allowedMentions: { parse: [] }
            });

            Users.push(button.user.id);
            
            // Atualiza o botão com o número de participantes
            const UpdatedButton = new ButtonBuilder()
                .setLabel(`Participar (${Users.length})`)
                .setEmoji('🎉')
                .setCustomId('g-join')
                .setStyle(ButtonStyle.Primary);

            const UpdatedRow = new ActionRowBuilder().setComponents(UpdatedButton);

            await button.update({ components: [UpdatedRow] }).catch(() => {});

            button.reply({
                content: `✅ Você entrou com sucesso no sorteio! Boa sorte!`,
                ephemeral: true
            });
        });

        Collector.on('end', async (undefined, reason) => {
            if (reason !== 'time') return;
            if (Users.length < 1) {
                Message.edit({ components: [] });
                return message.reply(`${client.config.emojis.error} ${message.author}, não haviam participantes suficientes nesse drop.`);
            }

            if (Winners > Users.length) Winners = Users.length;
            let WinnerList = [];

            for (let i = 0; i < Winners; i++) {
                let user = Users[parseInt(Math.random() * Users.length)];
                WinnerList.push(user);
                Users = Users.filter(x => x !== user);
            }

            for (let i of WinnerList) 
                client.mysql.updateUserMoney(i, Value);
            
            let EmbedFields = Message.embeds[0].data;
            if (!EmbedFields.fields) EmbedFields.fields = []; // Inicializa fields se não estiver definido
            EmbedFields.fields[2] = { name: `Ganhadores`, value: `${WinnerList.map(u => ` <@${u}>`).join(',')}` };

            Message?.edit({ embeds: [EmbedFields], components: [] }).catch(() => null);
            Message?.reply({
                content: `\n 🎁 | ${WinnerList.map(m => ` <@${m}>`).join(',')} ${WinnerList.length > 1 ? 'foram os sortudos e ganharam' : 'foi o sortudo e ganhou'} **${Value.toLocaleString()} Libras **`
            });
        });
    }
}
