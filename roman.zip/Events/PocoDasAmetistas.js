const Discord = require('discord.js')
const { EmbedBuilder, MessageCollector } = Discord;
const ms = require('ms');

const words = ['POÇO', 'ESCAVAR', 'PEGAR', 'PARTICIPAR', 'JUJUBINHAS', 'JUJUBA', 'DISCORD', 'GANHEI', 'SOCORRO', 'DESEJOS',"SKY"];
const winnerLimitPerChannel = 3;
const intervalMinutes = 30;
const timeToRespond = ms('40s');

const inflaçao = { min: 100_000, max: 850_000 };

const nextTime = () => ms(`${intervalMinutes - new Date().getMinutes() % intervalMinutes}m`);
const getRandomWord = () => words[~~(Math.random() * words.length)];
const getRandomMoney = () => Math.floor(Math.random() * (inflaçao.max - inflaçao.min)) + inflaçao.min;

module.exports = {
    name: 'ready',
    /** @param {import('../Base/client')} client */
    execute: async (client) => {
        setTimeout(() => setupDesejos(), nextTime());

        async function setupDesejos() {
            // Recarregando
            setTimeout(() => setupDesejos(), nextTime()); 

            // Se estiver desativado
            const status = await client.mysql.getStephanieStatus();
            if (status.maintenance) return;

            // Buscando canais
            const PoçoData = await client.mysql.getDesejosData();
            if (!PoçoData.channels.length) return;
            const wordChannels = [];

            // Loop nos canais
            for (const channelId of PoçoData.channels) {
                /** @type {{ channel: string, word: string, users: Discord.User[], rejectedUsers: Discord.User[] }[]}} */

                // Enviando mensagem nos canais
                const channel = await client.channels.fetch(channelId).catch(() => null);
                if (!channel) continue;
                
                if (!wordChannels.find(f => f.channel === channel.id)) wordChannels.push({
                    channel: channel.id,
                    word: getRandomWord(),
                    users: [],
                    rejectedUsers: [],
                });

                const channelData = wordChannels.find(f => f.channel === channelId);

                // Ajustando resposta
                const embedRes = new EmbedBuilder()
                    .setTitle(`Poço Das Ametistas`)
                    .setDescription(`Um novo Poço de Ametistas foi encontrado, diga a palavra a seguir corretamente para receber Ametistas!` +
                        `\nE seja rápido, pois apenas **os ${winnerLimitPerChannel} primeiros** que escreverem ganharão.` +
                        `\n\n:pencil: **Escreva... \`${channelData.word}\`**`)
                    .setThumbnail(channel.guild.iconURL({ format: 'png', dynamic: true }))
                    .setColor(client.config.colors.default)
                    .setFooter({ text: 'Poço de Quartzos', iconURL: channel.guild.iconURL() })
                    .setTimestamp();
            
                const msg = await channel.send({
                    content: '<@&1137061503724421210>',
                    embeds: [embedRes],
                }).catch(() => null);

                // Criando coletor de mensagem 

                const collector = new MessageCollector(channel, { 
                    filter: f => f.content.toLowerCase() === channelData.word.toLowerCase(), time: timeToRespond })

                collector.on('collect', (message) => {
                    if (channelData.users.some(s => s.id === message.author.id)) return;

                    if (channelData.users.length >= 3) channelData.rejectedUsers.push(message.author);
                    else {
                        channelData.users.push(message.author);
                        message.react(['🏆', '🥈', '🥉'][channelData.users.length - 1]).catch(() => null);
                    }
                });

                collector.on('end', async (undefined, reason) => {
                    if (reason !== 'time') return msg?.delete().catch(() => null);
                    if (!channelData.users?.length) return msg.delete().catch(() => null);
                    const prize = getRandomMoney();

                    // Pagando usuários
                    for (const user of channelData.users) {
                        client.mysql.updateUserMoney(user.id, prize);
                        
                        client.mysql.createNewTransaction({
                            source: 9,
                            given_at: Date.now(),
                            received_by: user.id,
                            amount: prize,
                        });
                    }

                    // Respondendo sobre ganhadores
                    const msg2 = await msg.reply(`:tada: **Ganhadores** | Poço de Quartzos | **${client.config.emojis.money} ${client.util.AbbreviateNumber(prize)} Quartzos**\n${channelData.users.map(m => `| ${m}`).join('\n')}`);

                    // Respondendo sobre todos que tentaram
                    setTimeout(() => {
                        let users = [];
                        const arrayUsers = wordChannels.map(m => [...m.users.map(m => m.tag), ...m.rejectedUsers.map(m => m.tag)]);
                        
                        for (const user of arrayUsers) users.push(...user);
                        users = [...new Set(users)];

                        msg2.reply(`Ao todo **${users.length} ${users.length === 1 ? 'usuário** participou:' : 'usuários** participaram:'} \`${users.join(', ')}\``)

                        return msg.delete(() => null);
                    }, ms('10s'));
                }); // * End "end" Collector
            } // * End loop
        } // * End Function
    }
}